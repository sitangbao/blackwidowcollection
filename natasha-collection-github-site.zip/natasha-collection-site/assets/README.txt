把商品图片放在这个文件夹，并在 data.js 中填写相对路径，例如 assets/nat-001.webp
